#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from collections import OrderedDict

# pfm module
PFM_HEAD_FMT  = '<IBBHI16sI'
PFM_HEAD_SIZE = 0x20

PFM_MAGIC      = 0x02B3CE1D
FVM_MAGIC      = 0xA8E7C2D4
PFM_SPI_REG_DEF  = 0x1
PFM_SMB_RULE_DEF = 0x2
PFM_FVM_SPI_REG  = 0x3
PFR_PFM_OFFSET = 0x02FF0000

PFM_HEAD_FMT, PFM_HEAD_KEY = '<IBBHI16sI', ('tag', 'svn', 'bkc_rev', 'pfm_rev', 'rsvd1', 'oem_data', 'length')
PFM_BODY_SPI_FMT, PFM_BODY_SPI_KEY = '<BBHIII',   ('type', 'mask', 'hash_alg', 'rsvd1', 'reg_start', 'reg_end')
PFM_BODY_SMB_FMT, PFM_BODY_SMB_KEY = '<BIBBB32s', ('type', 'rsvd1', 'bus_id', 'rule_id', 'smb_addr', 'smb_passlist')
PFM_BODY_FVM_FMT, PFM_BODY_FVM_KEY = '<BH5sI',    ('type', 'fv_type', 'rsvd1', 'fvm_addr')

FVM_MAGIC  = 0xA8E7C2D4
FVM_HEAD_FMT, FVM_HEAD_KEY = '<IBBHHH16sI', ('tag', 'svn', 'rsvd1', 'fvm_rev', 'rsvd2', 'fv_type', 'oem_data', 'length')
FVM_BODY_SPI_FMT, FVM_BODY_SPI_KEY = '<BBHIII',   ('type', 'mask', 'hash_alg', 'rsvd1', 'reg_start', 'reg_end')
FVM_BODY_CAP_FMT, FVM_BODY_CAP_KEY = '<BHBHIII26s20s',   ('type', 'rsvd1', 'rev', 'size', 'seamless_pkg_ver', 'seamless_layout_id', 'seamless_post_act', 'rsvd2', 'seamless_fw_disc')

# for nested dictionary
class ConfigDict(OrderedDict):
  """ define an ordered dictionary """
  def __missing__(self, key):
    val = self[key] = ConfigDict()
    return val


# capsule module

